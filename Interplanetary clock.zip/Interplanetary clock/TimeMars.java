import java.text.SimpleDateFormat;
import java.util.Date;
import java.math.*;

public class TimeMars{

	public static void main(String[] args) {

 double diffts = 1014330*0.97363083164;	
	// double diffts1 = diffTime * 0.9736308; // this factor is calculated for mars
	// long mars seconds = diiifts 
	// long double diffts = diffts1;
	
	 double day = diffts / 86400; 
	 double dayd = diffts % 86400; 
	 double hr = dayd / 3600; 
	 double  hrd  = dayd % 3600;
	double min = hrd / 60;
	double minutesd = hrd % 3600;
	 double sec = minutesd % 60; 
 
  
			int day1 =(int) day;
		int hr1 =(int) hr;
	 int min1=(int) min;
		 int sec1 =(int) sec;
	
 
 System.out.println("difference is days "+day1);
 System.out.println("difference is  hours "+hr1);
 System.out.println("difference is minutes "+min1);
 System.out.println("difference is  seconds "+sec1);
 

/*
		if(diffDegmin != 4950 ){
			if(diffSeconds2>0){s
				//calculate date from diffts
			long diffts1  = diffts - 4*diffDegmin; 
			}
			else{
				 //calculate date from diffts1
				long diffts2  = diffts + 4*diffDegmin;
			}
		}
		else{
			//calculate date from diifts
			

		}
		
	*/
		}
	
	
}