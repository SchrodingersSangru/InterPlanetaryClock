import javax.swing.*; 

public class dabce{

	public static void main(String[] args) {

	//
		int degreesDefault = 4950*60;
		String degreeUser = JOptionPane.showInputDialog("Enter the degrees ° format on which Martian longitude you would like to find time ");
		int degreesDef = Integer.parseInt(degreeUser);
		int degreesDefined = degreesDef*3600;
		
		try {
			int diffSeconds = degreesDefined - degreesDefault; 
			System.out.println("difference between longitude is "+degreesDefined);
			System.out.println("difference between longitude is "+degreesDefault);
			System.out.println("difference between longitude is "+diffSeconds+" in seconds.");
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}