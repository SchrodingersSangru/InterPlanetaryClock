import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*; 

public class abdce{

	public static void main(String[] args) {

		System.out.println("Input date and time should be greater than 01/01/2019 00:00:01 in MM/dd/yyyy HH:mm:ss format");
		String dateDefault = "01/01/2019 00:00:01";
		String dateDefined = JOptionPane.showInputDialog("Enter the date in MM/dd/yyyy HH:mm:ss format");

		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(dateDefault);
			d2 = format.parse(dateDefined);

			
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds2 = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);

			System.out.println(diffDays + " days, ");
			System.out.println(diffHours + " hours, ");
			System.out.println(diffMinutes + " minutes, ");
			System.out.println(diffSeconds2 + " seconds.");
			
			long diffTime = diffDays*86400+diffHours*60*60+diffMinutes*60+diffSeconds2;
			System.out.println("difference between time is "+diffTime+" in seconds.");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}